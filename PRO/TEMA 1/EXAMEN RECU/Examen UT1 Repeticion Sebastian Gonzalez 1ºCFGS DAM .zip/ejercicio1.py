# Ejercicio 001 (4.0 puntos)

import random

nombre = input("Introduce el nombre completo: ")
nif = input("Introduce el NIF/NIE: ")
nombredep = input("Introduzca el nombre del departamento: ")

#primera parte del departamento
while True:
    